# SSDD > 2022-05-05 1:26pm
https://universe.roboflow.com/k--stavrakakis/ssdd

Provided by a Roboflow user
License: CC BY 4.0

